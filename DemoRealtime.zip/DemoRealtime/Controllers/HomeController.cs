﻿using DemoRealtime.Hubs;
using DemoRealtime.Models;
using Microsoft.AspNet.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace DemoRealtime.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        private List<Product> listpro;
        private string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            var random = new Random();
            return new string(Enumerable.Repeat(chars, length).Select(s => s[random.Next(s.Length)]).ToArray());
        }
        public ActionResult Admin()
        {
            return View();
        }
        public ActionResult ClearCart()
        {
            Session["cart"] = null;
            FormsAuthentication.SetAuthCookie(RandomString(8), true);
            return Json(new { success = true, cartcount = 0 },JsonRequestBehavior.AllowGet);
        }
        public ActionResult Index()
        {
            if (!User.Identity.IsAuthenticated)
            {
                FormsAuthentication.SetAuthCookie(RandomString(8), true);
            }
            if (Session["cart"]!=null)
            {
                var cart = (List<DemoRealtime.Models.Product>)Session["cart"];
                var hubContext = GlobalHost.ConnectionManager.GetHubContext<UserHub>();
                hubContext.Clients.Group("admin").UpdateCart(User.Identity.Name, cart);
            }
            getListPro();
            return View(listpro);
        }

        public ActionResult Cart()
        {
            if (Session["cart"] != null)
            {
                var cart = (List<DemoRealtime.Models.Product>)Session["cart"];
                var hubContext = GlobalHost.ConnectionManager.GetHubContext<UserHub>();
                hubContext.Clients.Group("admin").UpdateCart(User.Identity.Name, cart);
            }
            return View();
        }

        private void getListPro()
        {
            if (listpro == null)
            {
                listpro = new List<Product>();
                listpro.Add(new Product() { ID = 1, Image = "/Contents/images/iphone6s.jpg", Price = "$399 ~ $415", Name = "Iphone 6s" });
                listpro.Add(new Product() { ID = 2, Image = "/Contents/images/lgg5.jpg", Price = "$299 ~ $315", Name = "LG G5" });
            }
        }
        public ActionResult updateCart(int productid, int quantity, int action)
        {
            getListPro();//list product
            List<DemoRealtime.Models.Product> cart;
            if (Session["cart"] != null)
            {
                cart = (List<DemoRealtime.Models.Product>)Session["cart"];
            }
            else
            {
                cart = new List<DemoRealtime.Models.Product>();
            }
            var pro = listpro.Where(m => m.ID == productid).FirstOrDefault();
            if (pro != null)
            {
                var hubContext = GlobalHost.ConnectionManager.GetHubContext<UserHub>();

                var proincart = cart.Where(m => m.ID == productid).FirstOrDefault();//in cart have product
                if (proincart != null)
                {
                    if (action == 1)
                        cart.Remove(proincart);
                    else if (action == 3)
                    {
                        proincart.CartQuantity = quantity;
                    }

                    hubContext.Clients.Group("admin").UpdateCart(User.Identity.Name, cart);
                    Session["cart"] = cart;
                    return Json(new { success = true, cartcount = cart.Count });
                }
                else
                {
                    if (action == 0)
                    {
                        pro.CartQuantity = quantity;
                        cart.Add(pro);


                        hubContext.Clients.Group("admin").UpdateCart(User.Identity.Name, cart);
                    }
                    Session["cart"] = cart;
                    return Json(new { success = true, cartcount = cart.Count });
                }

            }
            else
                return Json(new { success = false });
        }
    }
}
