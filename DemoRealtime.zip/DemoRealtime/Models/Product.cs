﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoRealtime.Models
{
    public class Product
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Image { get; set; }

        public int CartQuantity { get; set; }
        public int RecommendUnitPrice { get; set; }// by staff
        public int RecommendPrice { get; set; }// by staff

        public string Price { get; set; }
    }
}
