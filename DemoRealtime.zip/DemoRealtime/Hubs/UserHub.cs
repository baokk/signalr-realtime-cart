﻿using Microsoft.AspNet.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DemoRealtime.Hubs
{
    public class UserHub : Hub
    {
        public override System.Threading.Tasks.Task OnConnected()
        {
            var id = Context.ConnectionId;
            Clients.Client(id).getMyid(Context.User.Identity.Name);
            Groups.Add(id, Context.User.Identity.Name);
            Clients.Group("admin").newClient(Context.User.Identity.Name);
            return base.OnConnected();
        }
        public void joinadmin()
        {
            var id = Context.ConnectionId;
            Groups.Add(id, "admin");
        }
        //completeorder
        public void completeorder()
        {
            //var id = Context.ConnectionId;
            Clients.Group("admin").completeorder(Context.User.Identity.Name);
        }
        public void updateinfo(string name,string phone,string address)
        {
            //var id = Context.ConnectionId;
            Clients.Group("admin").updateinfo(Context.User.Identity.Name,name, phone, address);
        }
        public override System.Threading.Tasks.Task OnDisconnected()
        {
            var id = Context.ConnectionId;
            Groups.Remove(id, Context.User.Identity.Name);
            Clients.Group("admin").removeClient(Context.User.Identity.Name);
            return base.OnDisconnected();
        }
    }
}